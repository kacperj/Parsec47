
// Implementation is in internal\object.d

module object;

//alias bit bool;
alias bool bit;

alias typeof(int.sizeof) size_t;
alias typeof(cast(void*)0 - cast(void*)0) ptrdiff_t;
alias size_t hash_t;

alias char[] string;
alias wchar[] wstring;
alias dchar[] dstring;

version (X86_64)
{
    alias long c_long;
    alias ulong c_ulong;
}
else
{
    alias int c_long;
    alias uint c_ulong;
}

extern (C)
{   int printf(char *, ...);
    void trace_term();
}

class Object
{
    void print();
    char[] toString();
    hash_t toHash();
    int opCmp(Object o);
    int opEquals(Object o);

    final void notifyRegister(void delegate(Object) dg);
    final void notifyUnRegister(void delegate(Object) dg);

    static Object factory(char[] classname);
}

struct Interface
{
    ClassInfo classinfo;
    void *[] vtbl;
    int offset;                 // offset to Interface 'this' from Object 'this'
}

class ClassInfo : Object
{
    byte[] init;                // class static initializer
    char[] name;                // class name
    void *[] vtbl;              // virtual function pointer table
    Interface[] interfaces;
    ClassInfo base;
    void *destructor;
    void (*classInvariant)(Object);
    uint flags;
    //  1:                      // IUnknown
    //  2:                      // has no possible pointers into GC memory
    //  4:                      // has offTi[] member
    //  8:                      // has constructors
    //  32:                     // has typeinfo
    //  64:                     // is abstract (not constructable)
    void *deallocator;
    OffsetTypeInfo[] offTi;
    void* defaultConstructor;   // default Constructor
    TypeInfo typeinfo;

    static ClassInfo find(char[] classname);
    Object create();
}

struct OffsetTypeInfo
{
    size_t offset;
    TypeInfo ti;
}

class TypeInfo
{
    hash_t getHash(void *p);
    int equals(void *p1, void *p2);
    int compare(void *p1, void *p2);
    size_t tsize();
    void swap(void *p1, void *p2);
    TypeInfo next();
    void[] init();
    uint flags();
    // 1:                       // has possible pointers into GC memory
    OffsetTypeInfo[] offTi();
    size_t talign();
    version (X86_64) int argTypes(out TypeInfo arg1, out TypeInfo arg2);
}

class TypeInfo_Typedef : TypeInfo
{
    TypeInfo base;
    char[] name;
    void[] m_init;
}

class TypeInfo_Enum : TypeInfo_Typedef
{
}

class TypeInfo_Pointer : TypeInfo
{
    TypeInfo m_next;
}

class TypeInfo_Array : TypeInfo
{
    char[] toString();
    int opEquals(Object o);
    hash_t getHash(void *p);
    int equals(void *p1, void *p2);
    int compare(void *p1, void *p2);
    size_t tsize();
    void swap(void *p1, void *p2);
    TypeInfo next();
    uint flags();
    size_t talign();
    version (X86_64) int argTypes(out TypeInfo arg1, out TypeInfo arg2);

    TypeInfo value;
}

class TypeInfo_StaticArray : TypeInfo
{
    TypeInfo value;
    size_t len;
}

class TypeInfo_AssociativeArray : TypeInfo
{
    TypeInfo value;
    TypeInfo key;
}

class TypeInfo_Function : TypeInfo
{
    TypeInfo next;
}

class TypeInfo_Delegate : TypeInfo
{
    TypeInfo next;
}

class TypeInfo_Class : TypeInfo
{
    ClassInfo info;
}

class TypeInfo_Interface : TypeInfo
{
    ClassInfo info;
}

class TypeInfo_Struct : TypeInfo
{
    char[] name;
    void[] m_init;

    uint function(void*) xtoHash;
    int function(void*,void*) xopEquals;
    int function(void*,void*) xopCmp;
    char[] function(void*) xtoString;

    uint m_flags;
    uint m_align;

    version (X86_64)
    {
        TypeInfo m_arg1;
        TypeInfo m_arg2;
    }
}

class TypeInfo_Tuple : TypeInfo
{
    TypeInfo[] elements;
}

class TypeInfo_Const : TypeInfo
{
    TypeInfo next;
}

class TypeInfo_Invariant : TypeInfo_Const
{
}

// Recoverable errors

class Exception : Object
{
    string msg;

    this(string msg);
    override void print();
    override string toString();
}

// Non-recoverable errors

class Error : Exception
{
    Error next;

    this(string msg);
    this(string msg, Error next);
}

